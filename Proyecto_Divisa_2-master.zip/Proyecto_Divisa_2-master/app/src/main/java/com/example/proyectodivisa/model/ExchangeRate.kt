package com.example.proyectodivisa.model

data class ExchangeRate(val date: String, val rate: Double, val change: String)