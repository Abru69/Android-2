package com.example.consumirprovider

data class ExchangeRate(val date: String, val rate: Double, val change: String)